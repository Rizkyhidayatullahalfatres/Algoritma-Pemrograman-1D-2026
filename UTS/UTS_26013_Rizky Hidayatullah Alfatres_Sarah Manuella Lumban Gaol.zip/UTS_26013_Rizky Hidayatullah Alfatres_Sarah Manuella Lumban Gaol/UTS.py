Regular = 40000
VIP = 75000
VVIP = 100000

ticket = str(input("Masukan jenis ticket yang ingin dibeli: "))
jumlah = int(input("Masukan seberapa banyak ticket yang ingin di beli: "))

